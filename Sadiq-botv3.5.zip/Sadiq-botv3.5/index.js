import makeWASocket, { 
    useMultiFileAuthState, 
    DisconnectReason, 
    downloadContentFromMessage,
    makeCacheableSignalKeyStore
} from '@whiskeysockets/baileys';
import pino from 'pino';
import yts from 'yt-search';
import fs from 'fs';
import path from 'path';
import axios from 'axios';
import http from 'http';
import NodeCache from 'node-cache';
import { Sticker, StickerTypes } from 'wa-sticker-formatter';
import { MAIN_MENU, OWNER_NAME } from './menu.js';

// ================= CONFIGURATION =================
const OWNER_PHONE = "2348125149399"; 

// NVIDIA API Configuration & Model Fallback Pool
const NVIDIA_API_KEY = "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";
const NVIDIA_ENDPOINT = "https://integrate.api.nvidia.com/v1/chat/completions";
const NVIDIA_MODELS = [
    "meta/llama-3.1-70b-instruct",
    "meta/llama-3.1-8b-instruct",
    "mistralai/mistral-large-2-instruct",
    "nvidia/nemotron-4-340b-instruct"
];

const KEYS_FILE = './apikeys.json';
const DEFAULT_TUNELIO_KEY = "tnl_M5VpYSSeXFKEMD2XDjqNeTBy89uAt0i9dtmHUiPQX48";

// Message retry cache to resolve decryption issues safely
const msgRetryCounterCache = new NodeCache();

// Initialize API Key Pool File if it doesn't exist
if (!fs.existsSync(KEYS_FILE)) {
    fs.writeFileSync(KEYS_FILE, JSON.stringify([DEFAULT_TUNELIO_KEY], null, 2));
}

// Helper: Get all API keys
function getApiKeys() {
    try {
        const data = fs.readFileSync(KEYS_FILE, 'utf8');
        const keys = JSON.parse(data);
        return Array.isArray(keys) && keys.length > 0 ? keys : [DEFAULT_TUNELIO_KEY];
    } catch {
        return [DEFAULT_TUNELIO_KEY];
    }
}

// Helper: Save API keys
function saveApiKeys(keys) {
    fs.writeFileSync(KEYS_FILE, JSON.stringify([...new Set(keys)], null, 2));
}

// Helper: Remove exhausted or invalid API key
function removeApiKey(keyToRemove) {
    let keys = getApiKeys();
    keys = keys.filter(k => k !== keyToRemove);
    if (keys.length === 0) keys.push(DEFAULT_TUNELIO_KEY); // Keep at least default fallback
    saveApiKeys(keys);
}

const globalSettings = { 
    antiCall: true, 
    autoViewStatus: true,
    publicMode: true, 
    aiAutoReply: false 
};

const sessionSettings = {}; 

if (!fs.existsSync('./downloads')) fs.mkdirSync('./downloads');
if (!fs.existsSync('./sessions')) fs.mkdirSync('./sessions');

// Ensure banner exists
async function ensureBanner() {
    const bannerPath = './banner.jpg';
    if (!fs.existsSync(bannerPath)) {
        try {
            const bannerUrl = 'https://placehold.co/600x400/0f172a/38bdf8.png?text=SADIQ-MD+BOT+%7C+GFA';
            const response = await axios({ url: bannerUrl, responseType: 'arraybuffer' });
            fs.writeFileSync(bannerPath, Buffer.from(response.data));
        } catch (err) {
            console.log('⚠️ Banner creation skipped.');
        }
    }
}

await ensureBanner();

// Helper: NVIDIA AI Engine with Automatic Model Fallback Rotation
async function fetchAIResponse(userPrompt, userId) {
    for (const model of NVIDIA_MODELS) {
        try {
            const res = await axios.post(NVIDIA_ENDPOINT, {
                model: model,
                messages: [
                    { role: "system", content: "You are Sadiq-MD, a helpful, friendly WhatsApp AI assistant." },
                    { role: "user", content: userPrompt }
                ],
                temperature: 0.7,
                max_tokens: 1024
            }, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${NVIDIA_API_KEY}`
                },
                timeout: 15000
            });

            const answer = res.data?.choices?.[0]?.message?.content;
            if (answer) return answer.trim();
        } catch (err) {
            console.log(`⚠️ NVIDIA Model ${model} failed, trying next model...`);
        }
    }
    return `❌ AI Error: All NVIDIA models failed to respond at the moment.`;
}

// Helper: Media Stream Downloader to Buffer
async function downloadMediaBuffer(quotedMsg, type) {
    const stream = await downloadContentFromMessage(quotedMsg, type);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
}

// ================= WHATSAPP ENGINE =================
async function startWhatsAppSession(sessionName = "main_session") {
    const sessionDir = path.join('./sessions', sessionName);
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

    const sock = makeWASocket({
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })),
        },
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false,
        msgRetryCounterCache,
        markOnlineOnConnect: true,
        syncFullHistory: false
    });

    if (!sock.authState.creds.registered) {
        setTimeout(async () => {
            try {
                const code = await sock.requestPairingCode(OWNER_PHONE);
                console.log(`\n==============================================`);
                console.log(`🔑 YOUR WHATSAPP PAIRING CODE IS: ${code}`);
                console.log(`==============================================\n`);
            } catch (err) {
                console.log('❌ Failed to generate pairing code:', err.message);
            }
        }, 3000);
    }

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            if (shouldReconnect) startWhatsAppSession(sessionName);
        } else if (connection === 'open') {
            console.log(`✅ [${sessionName}] Sadiq-MD Connected Successfully!`);
        }
    });

    sock.ev.on('creds.update', saveCreds);

    // Anti-Call Handler
    sock.ev.on('call', async (calls) => {
        if (!globalSettings.antiCall) return;
        for (const call of calls) {
            if (call.status === 'offer') {
                await sock.rejectCall(call.id, call.from);
                await sock.sendMessage(call.from, { text: '⚠️ Calls are automatically blocked by Sadiq Bot.' });
            }
        }
    });

    // Message Upsert Processor
    sock.ev.on('messages.upsert', async ({ messages }) => {
        const m = messages[0];
        if (!m.message) return;

        const senderJid = m.key.remoteJid;
        const participant = m.key.participant || senderJid;
        const isGroup = senderJid.endsWith('@g.us');
        const rawSenderNumber = (m.key.fromMe ? sock.user.id : participant).split('@')[0].split(':')[0];
        const isOwner = rawSenderNumber === OWNER_PHONE || m.key.fromMe;

        // Auto View Status
        if (senderJid === 'status@broadcast' && globalSettings.autoViewStatus) {
            await sock.readMessages([m.key]);
            return;
        }

        const textContent = m.message.conversation || 
                            m.message.extendedTextMessage?.text || 
                            m.message.imageMessage?.caption || 
                            m.message.videoMessage?.caption || '';

        // Anti-Link protection
        if (isGroup && sessionSettings[senderJid]?.antiLink) {
            const linkRegex = /(https?:\/\/[^\s]+|chat\.whatsapp\.com\/[^\s]+)/gi;
            if (linkRegex.test(textContent)) {
                await sock.sendMessage(senderJid, { delete: m.key });
                await sock.sendMessage(senderJid, { text: `⚠️ Links are prohibited here, @${rawSenderNumber}!`, mentions: [participant] });
                return;
            }
        }

        // Auto AI reply listener for private messages
        if (!textContent.startsWith('.') && !isGroup && globalSettings.aiAutoReply && !m.key.fromMe) {
            const aiReply = await fetchAIResponse(textContent, senderJid);
            await sock.sendMessage(senderJid, { text: aiReply });
            return;
        }

        if (!textContent.startsWith('.')) return;

        const args = textContent.slice(1).trim().split(/ +/);
        const command = args.shift().toLowerCase();

        if (!globalSettings.publicMode && !isOwner) {
            return await sock.sendMessage(senderJid, { text: '🔒 *Sadiq Bot is in Self Mode.* Only the owner can use commands.' });
        }

        switch (command) {
            case 'menu':
            case 'help':
                try {
                    await sock.sendMessage(senderJid, { 
                        image: { url: './banner.jpg' }, 
                        caption: MAIN_MENU + `\n\n⚙️ *Mode:* ${globalSettings.publicMode ? 'Public 🌐' : 'Self 🔒'}` 
                    });
                } catch {
                    await sock.sendMessage(senderJid, { text: MAIN_MENU });
                }
                break;

            case 'ping':
                await sock.sendMessage(senderJid, { text: '🏓 Pong! Sadiq Bot system operating at peak speed.' });
                break;

            case 'owner':
                await sock.sendMessage(senderJid, { text: `👑 *Owner Contact*\nName: ${OWNER_NAME}\nPhone: +${OWNER_PHONE}\nPlatform: Sadiq-MD Multi-Bot` });
                break;

            case 'fliptext': {
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.fliptext hello world`' });
                const textToFlip = args.join(' ');
                const flipped = textToFlip.split('').reverse().join('');
                await sock.sendMessage(senderJid, { text: `🔄 *Flipped Text:*\n\`${flipped}\`` });
                break;
            }

            case 'profile': {
                try {
                    let targetUser = senderJid;
                    if (m.message.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                        targetUser = m.message.extendedTextMessage.contextInfo.mentionedJid[0];
                    }
                    const ppUrl = await sock.profilePictureUrl(targetUser, 'image').catch(() => 'https://placehold.co/400x400/0f172a/38bdf8.png?text=No+Profile+Pic');
                    await sock.sendMessage(senderJid, { image: { url: ppUrl }, caption: '👤 *Profile Picture Fetched by Sadiq Bot*' });
                } catch (e) {
                    await sock.sendMessage(senderJid, { text: '❌ Could not retrieve profile picture.' });
                }
                break;
            }

            // ================= NEW UTILITY TOOLS =================
            case 'ss':
            case 'ssweb': {
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.ss https://google.com`' });
                const targetUrl = args[0];
                const ssUrl = `https://api.screenshotmachine.com/?key=free&url=${encodeURIComponent(targetUrl)}&dimension=1024x768`;
                await sock.sendMessage(senderJid, { image: { url: ssUrl }, caption: `📸 Screenshot of: ${targetUrl}` });
                break;
            }

            case 'makeqr': {
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.makeqr <text or url>`' });
                const qrText = args.join(' ');
                const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(qrText)}`;
                await sock.sendMessage(senderJid, { image: { url: qrUrl }, caption: `🔲 QR Code generated for: ${qrText}` });
                break;
            }

            case 'tinyurl':
            case 'short': {
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.short <url>`' });
                try {
                    const res = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(args[0])}`);
                    await sock.sendMessage(senderJid, { text: `🔗 *Shortened URL:*\n${res.data}` });
                } catch (e) {
                    await sock.sendMessage(senderJid, { text: '❌ Failed to shorten URL.' });
                }
                break;
            }

            case 'calc': {
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.calc 25 * 4 + 10`' });
                try {
                    const expression = args.join(' ');
                    // Safe evaluation check for math
                    if (!/^[\d\+\-\*\/\.\(\)\s]+$/.test(expression)) {
                        return sock.sendMessage(senderJid, { text: '❌ Invalid mathematical expression.' });
                    }
                    const result = eval(expression);
                    await sock.sendMessage(senderJid, { text: `🔢 *Result:* ${result}` });
                } catch (e) {
                    await sock.sendMessage(senderJid, { text: '❌ Calculation error.' });
                }
                break;
            }

            case 'base64': {
                if (args.length < 2) return sock.sendMessage(senderJid, { text: 'Usage: `.base64 encode <text>` or `.base64 decode <code`' });
                const action = args[0].toLowerCase();
                const textVal = args.slice(1).join(' ');
                if (action === 'encode') {
                    const encoded = Buffer.from(textVal).toString('base64');
                    await sock.sendMessage(senderJid, { text: `🔐 *Encoded:*\n\`${encoded}\`` });
                } else if (action === 'decode') {
                    const decoded = Buffer.from(textVal, 'base64').toString('utf8');
                    await sock.sendMessage(senderJid, { text: `🔓 *Decoded:*\n\`${decoded}\`` });
                } else {
                    await sock.sendMessage(senderJid, { text: 'Usage: `.base64 encode <text>` or `.base64 decode <code`' });
                }
                break;
            }

            // ================= NEW GROUP MANAGEMENT TOOLS =================
            case 'tagall':
            case 'everyone': {
                if (!isGroup) return sock.sendMessage(senderJid, { text: '❌ Group-only command.' });
                const metadata = await sock.groupMetadata(senderJid);
                let tagText = '📢 *Everyone Notification*\n\n';
                const mentions = [];
                for (let member of metadata.participants) {
                    tagText += `@${member.id.split('@')[0]}\n`;
                    mentions.push(member.id);
                }
                await sock.sendMessage(senderJid, { text: tagText, mentions });
                break;
            }

            case 'hidetag': {
                if (!isGroup) return sock.sendMessage(senderJid, { text: '❌ Group-only command.' });
                if (!isOwner) return sock.sendMessage(senderJid, { text: '❌ Owner-only admin command.' });
                const metadata = await sock.groupMetadata(senderJid);
                const mentions = metadata.participants.map(m => m.id);
                const broadcastText = args.join(' ') || 'Announcement from Sadiq Bot';
                await sock.sendMessage(senderJid, { text: broadcastText, mentions });
                break;
            }

            case 'promote': {
                if (!isGroup) return sock.sendMessage(senderJid, { text: '❌ Group-only command.' });
                let targetUser = null;
                if (m.message.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                    targetUser = m.message.extendedTextMessage.contextInfo.mentionedJid[0];
                }
                if (!targetUser) return sock.sendMessage(senderJid, { text: '❌ Reply or mention someone to promote.' });
                await sock.groupParticipantsUpdate(senderJid, [targetUser], 'promote');
                await sock.sendMessage(senderJid, { text: '✅ User promoted to admin successfully.' });
                break;
            }

            case 'demote': {
                if (!isGroup) return sock.sendMessage(senderJid, { text: '❌ Group-only command.' });
                let targetUser = null;
                if (m.message.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                    targetUser = m.message.extendedTextMessage.contextInfo.mentionedJid[0];
                }
                if (!targetUser) return sock.sendMessage(senderJid, { text: '❌ Reply or mention someone to demote.' });
                await sock.groupParticipantsUpdate(senderJid, [targetUser], 'demote');
                await sock.sendMessage(senderJid, { text: '✅ User demoted successfully.' });
                break;
            }

            case 'kick':
            case 'remove': {
                if (!isGroup) return sock.sendMessage(senderJid, { text: '❌ Group-only command.' });
                let targetUser = null;
                if (m.message.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                    targetUser = m.message.extendedTextMessage.contextInfo.mentionedJid[0];
                }
                if (!targetUser) return sock.sendMessage(senderJid, { text: '❌ Mention someone to remove.' });
                await sock.groupParticipantsUpdate(senderJid, [targetUser], 'remove');
                await sock.sendMessage(senderJid, { text: '👢 User removed from group.' });
                break;
            }

            case 'group': {
                if (!isGroup) return sock.sendMessage(senderJid, { text: '❌ Group-only command.' });
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.group open` or `.group close`' });
                const action = args[0].toLowerCase();
                if (action === 'open') {
                    await sock.groupSettingUpdate(senderJid, 'not_announcement');
                    await sock.sendMessage(senderJid, { text: '🔓 Group opened! All participants can now send messages.' });
                } else if (action === 'close') {
                    await sock.groupSettingUpdate(senderJid, 'announcement');
                    await sock.sendMessage(senderJid, { text: '🔒 Group closed! Only admins can send messages.' });
                } else {
                    await sock.sendMessage(senderJid, { text: 'Usage: `.group open` or `.group close`' });
                }
                break;
            }

            case 'setname': {
                if (!isGroup) return sock.sendMessage(senderJid, { text: '❌ Group-only command.' });
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.setname <new name>`' });
                await sock.groupUpdateSubject(senderJid, args.join(' '));
                await sock.sendMessage(senderJid, { text: '✅ Group name updated successfully.' });
                break;
            }

            case 'setdesc': {
                if (!isGroup) return sock.sendMessage(senderJid, { text: '❌ Group-only command.' });
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.setdesc <new description>`' });
                await sock.groupUpdateDescription(senderJid, args.join(' '));
                await sock.sendMessage(senderJid, { text: '✅ Group description updated successfully.' });
                break;
            }

            case 'revoke':
            case 'resetlink': {
                if (!isGroup) return sock.sendMessage(senderJid, { text: '❌ Group-only command.' });
                await sock.groupRevokeInvite(senderJid);
                await sock.sendMessage(senderJid, { text: '🔄 Group invite link has been reset.' });
                break;
            }

            case 'grouplink': {
                if (!isGroup) return sock.sendMessage(senderJid, { text: '❌ Group-only command.' });
                try {
                    const code = await sock.groupInviteCode(senderJid);
                    await sock.sendMessage(senderJid, { text: `🔗 *Group Invite Link:*\nhttps://chat.whatsapp.com/${code}` });
                } catch (e) {
                    await sock.sendMessage(senderJid, { text: '❌ Failed to fetch group link. Make sure the bot is an admin.' });
                }
                break;
            }

            // ================= NEW FUN & ENTERTAINMENT =================
            case 'truth': {
                const truths = [
                    "What is your most embarrassing secret?",
                    "Have you ever lied to your best friend?",
                    "Who was your first celebrity crush?",
                    "What is the weirdest thing you have ever eaten?",
                    "Have you ever talked to yourself in the mirror?"
                ];
                const q = truths[Math.floor(Math.random() * truths.length)];
                await sock.sendMessage(senderJid, { text: `🎯 *Truth:* ${q}` });
                break;
            }

            case 'dare': {
                const dares = [
                    "Send a voice note singing your favorite song.",
                    "Type your last 3 Google searches in the chat.",
                    "Send a selfie right now with a funny face.",
                    "Call someone in your contacts and sing happy birthday.",
                    "Change your WhatsApp status to 'I love Sadiq-MD bot'."
                ];
                const d = dares[Math.floor(Math.random() * dares.length)];
                await sock.sendMessage(senderJid, { text: `🔥 *Dare:* ${d}` });
                break;
            }

            case 'fancy':
            case 'style': {
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.fancy Hello World`' });
                const stringVal = args.join(' ');
                // Simple stylized unicode conversion
                const fancyMap = {
                    a: '𝔞', b: '𝔟', c: '𝔠', d: 'd', e: '𝔢', f: '𝔣', g: '𝔤', h: '𝔥', i: '𝔦', j: '𝔧', k: '𝔨', l: '𝔩', m: '𝔪', n: '𝔫', o: '𝔬', p: '𝔭', q: '𝔮', r: '𝔯', s: '𝔰', t: '𝔱', u: '𝔲', v: '𝔳', w: '𝔴', x: '𝔁', y: '𝔶', z: '𝔷',
                    A: '𝔄', B: '𝔅', C: 'ℂ', D: '𝔇', E: '𝔈', F: '𝔉', G: '𝔊', H: 'ℌ', I: 'ℑ', J: '𝔍', K: '𝔎', L: '𝔏', M: '𝔐', N: '𝔑', O: '𝔒', P: '𝔓', Q: '𝔔', R: 'ℜ', S: '𝔖', T: '𝔗', U: '𝔘', V: '𝔙', W: '𝔚', X: '𝔛', Y: '𝔜', Z: 'ℨ'
                };
                const styled = stringVal.split('').map(c => fancyMap[c] || c).join('');
                await sock.sendMessage(senderJid, { text: `✨ *Fancy Text:*\n${styled}` });
                break;
            }

            case 'roll':
            case 'dice': {
                const rollNum = Math.floor(Math.random() * 6) + 1;
                await sock.sendMessage(senderJid, { text: `🎲 You rolled a *${rollNum}*!` });
                break;
            }

            case 'flip':
            case 'coin': {
                const coin = Math.random() < 0.5 ? 'Heads 🪙' : 'Tails 🪙';
                await sock.sendMessage(senderJid, { text: `🪙 Coin flip result: *${coin}*` });
                break;
            }

            case 'fact': {
                try {
                    const res = await axios.get('https://uselessfacts.jsph.pl/api/v2/facts/random');
                    await sock.sendMessage(senderJid, { text: `💡 *Random Fact:*\n${res.data.text}` });
                } catch {
                    await sock.sendMessage(senderJid, { text: '💡 Honey never spoils. Archaeologists have found pots of honey in ancient Egyptian tombs that are over 3,000 years old and still edible!' });
                }
                break;
            }

            case 'joke': {
                try {
                    const res = await axios.get('https://official-joke-api.appspot.com/random_joke');
                    await sock.sendMessage(senderJid, { text: `😂 *Joke:*\n${res.data.setup}\n_${res.data.punchline}_` });
                } catch {
                    await sock.sendMessage(senderJid, { text: '😂 Why do programmers prefer dark mode? Because light attracts bugs!' });
                }
                break;
            }

            case 'quote': {
                try {
                    const res = await axios.get('https://api.quotable.io/random');
                    await sock.sendMessage(senderJid, { text: `💬 *Quote:*\n"${res.data.content}"\n- *${res.data.author}*` });
                } catch {
                    await sock.sendMessage(senderJid, { text: '💬 "The best way to predict the future is to invent it." - Alan Kay' });
                }
                break;
            }

            // ================= NEW SEARCH & INFORMATION =================
            case 'weather': {
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.weather <city name>`' });
                const city = args.join(' ');
                try {
                    const res = await axios.get(`https://wttr.in/${encodeURIComponent(city)}?format=3`);
                    await sock.sendMessage(senderJid, { text: `🌤️ *Weather Report:*\n${res.data}` });
                } catch (e) {
                    await sock.sendMessage(senderJid, { text: '❌ Could not retrieve weather information.' });
                }
                break;
            }

            case 'wiki': {
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.wiki <query>`' });
                const query = args.join(' ');
                try {
                    const res = await axios.get(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`);
                    if (res.data && res.data.extract) {
                        await sock.sendMessage(senderJid, { text: `📖 *Wikipedia (${res.data.title}):*\n\n${res.data.extract}` });
                    } else {
                        await sock.sendMessage(senderJid, { text: '❌ No Wikipedia article found.' });
                    }
                } catch (e) {
                    await sock.sendMessage(senderJid, { text: '❌ Wikipedia search failed.' });
                }
                break;
            }

            case 'dictionary':
            case 'define': {
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.define <word>`' });
                const word = args[0];
                try {
                    const res = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`);
                    const def = res.data[0]?.meanings[0]?.definitions[0]?.definition;
                    const phonetic = res.data[0]?.phonetic || '';
                    if (def) {
                        await sock.sendMessage(senderJid, { text: `📚 *Definition of ${word}* ${phonetic}:\n\n${def}` });
                    } else {
                        await sock.sendMessage(senderJid, { text: '❌ Definition not found.' });
                    }
                } catch (e) {
                    await sock.sendMessage(senderJid, { text: '❌ Could not fetch word definition.' });
                }
                break;
            }

            // ================= API KEY POOL MANAGEMENT =================
            case 'addapikey': {
                if (!isOwner) return sock.sendMessage(senderJid, { text: '❌ Owner-only command.' });
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.addapikey tnl_xxxxxx...`' });
                const newKey = args[0].trim();
                let keys = getApiKeys();
                if (keys.includes(newKey)) {
                    return sock.sendMessage(senderJid, { text: '⚠️ This API key is already in the pool.' });
                }
                keys.push(newKey);
                saveApiKeys(keys);
                await sock.sendMessage(senderJid, { text: `✅ API Key added successfully!\nTotal active keys in pool: *${keys.length}*` });
                break;
            }

            case 'listkeys': {
                if (!isOwner) return sock.sendMessage(senderJid, { text: '❌ Owner-only command.' });
                const keys = getApiKeys();
                let msg = `🔑 *Active Tunelio API Keys (${keys.length}):*\n\n`;
                keys.forEach((k, idx) => {
                    msg += `${idx + 1}. \`${k.slice(0, 8)}...${k.slice(-4)}\`\n`;
                });
                await sock.sendMessage(senderJid, { text: msg });
                break;
            }

            case 'delapikey': {
                if (!isOwner) return sock.sendMessage(senderJid, { text: '❌ Owner-only command.' });
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.delapikey <key_or_index>`' });
                let keys = getApiKeys();
                const target = args[0].trim();
                
                let updatedKeys;
                if (!isNaN(target)) {
                    const index = parseInt(target) - 1;
                    if (index >= 0 && index < keys.length) {
                        const removed = keys.splice(index, 1);
                        updatedKeys = keys;
                        saveApiKeys(updatedKeys);
                        return sock.sendMessage(senderJid, { text: `🗑️ Removed API key at index ${target}.\nRemaining keys: *${updatedKeys.length}*` });
                    }
                }
                
                updatedKeys = keys.filter(k => k !== target);
                saveApiKeys(updatedKeys);
                await sock.sendMessage(senderJid, { text: `🗑️ API key removed if it existed.\nRemaining keys: *${updatedKeys.length}*` });
                break;
            }

            // ================= AI CONTROLS =================
            case 'ai': {
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.ai <your question>`' });
                const prompt = args.join(' ');
                await sock.sendMessage(senderJid, { text: '🤖 Thinking with NVIDIA AI...' });
                const aiReply = await fetchAIResponse(prompt, senderJid);
                await sock.sendMessage(senderJid, { text: aiReply });
                break;
            }

            case 'aion':
                if (!isOwner) return sock.sendMessage(senderJid, { text: '❌ Owner-only command.' });
                globalSettings.aiAutoReply = true;
                await sock.sendMessage(senderJid, { text: '🤖 *Auto AI listener is ON* for private chats.' });
                break;

            case 'aioff':
                if (!isOwner) return sock.sendMessage(senderJid, { text: '❌ Owner-only command.' });
                globalSettings.aiAutoReply = false;
                await sock.sendMessage(senderJid, { text: '🤖 *Auto AI listener is OFF*.' });
                break;

            // ================= GET STATUS / QUOTED MEDIA =================
            case 'get': {
                try {
                    const quotedMsg = m.message.extendedTextMessage?.contextInfo?.quotedMessage;
                    if (!quotedMsg) {
                        return sock.sendMessage(senderJid, { text: '❌ Reply to a status or media message with `.get`' });
                    }

                    const type = Object.keys(quotedMsg)[0];
                    if (type === 'imageMessage') {
                        const buffer = await downloadMediaBuffer(quotedMsg.imageMessage, 'image');
                        await sock.sendMessage(senderJid, { image: buffer, caption: quotedMsg.imageMessage.caption || '📥 Fetched by Sadiq Bot' });
                    } else if (type === 'videoMessage') {
                        const buffer = await downloadMediaBuffer(quotedMsg.videoMessage, 'video');
                        await sock.sendMessage(senderJid, { video: buffer, caption: quotedMsg.videoMessage.caption || '📥 Fetched by Sadiq Bot' });
                    } else if (type === 'audioMessage') {
                        const buffer = await downloadMediaBuffer(quotedMsg.audioMessage, 'audio');
                        await sock.sendMessage(senderJid, { audio: buffer, mimetype: 'audio/mp4' });
                    } else {
                        await sock.sendMessage(senderJid, { text: '❌ Unsupported media type for `.get`' });
                    }
                } catch (e) {
                    await sock.sendMessage(senderJid, { text: `❌ Failed to fetch media: ${e.message}` });
                }
                break;
            }

            // ================= VIEW ONCE UNLOCKER =================
            case 'vv':
            case 'reveal':
            case 'unlock': {
                try {
                    const quotedMsg = m.message.extendedTextMessage?.contextInfo?.quotedMessage;
                    if (!quotedMsg) {
                        return sock.sendMessage(senderJid, { text: '❌ Reply to a View Once photo or video with `.vv`' });
                    }

                    const actualMsg = quotedMsg.viewOnceMessage?.message || quotedMsg.viewOnceMessageV2?.message || quotedMsg;
                    const type = Object.keys(actualMsg)[0];

                    if (type === 'imageMessage') {
                        const buffer = await downloadMediaBuffer(actualMsg.imageMessage, 'image');
                        await sock.sendMessage(senderJid, { image: buffer, caption: '🔓 Unlocked View Once' });
                    } else if (type === 'videoMessage') {
                        const buffer = await downloadMediaBuffer(actualMsg.videoMessage, 'video');
                        await sock.sendMessage(senderJid, { video: buffer, caption: '🔓 Unlocked View Once' });
                    } else {
                        await sock.sendMessage(senderJid, { text: '❌ Quoted message is not View Once media.' });
                    }
                } catch (e) {
                    await sock.sendMessage(senderJid, { text: `❌ Failed to unlock: ${e.message}` });
                }
                break;
            }

            // ================= STICKER ENGINE =================
            case 'sticker':
            case 's': {
                try {
                    const quotedMsg = m.message.extendedTextMessage?.contextInfo?.quotedMessage || m.message;
                    const mediaType = quotedMsg.imageMessage ? 'image' : quotedMsg.videoMessage ? 'video' : null;

                    if (!mediaType) {
                        return sock.sendMessage(senderJid, { text: '❌ Reply to an image or video with `.sticker`' });
                    }

                    await sock.sendMessage(senderJid, { text: '⏳ Creating sticker...' });
                    const buffer = await downloadMediaBuffer(quotedMsg[mediaType + 'Message'], mediaType);

                    const sticker = new Sticker(buffer, {
                        pack: 'Sadiq Bot',
                        author: OWNER_NAME,
                        type: StickerTypes.FULL,
                        quality: 60
                    });

                    const stickerBuffer = await sticker.toBuffer();
                    await sock.sendMessage(senderJid, { sticker: stickerBuffer });
                } catch (e) {
                    await sock.sendMessage(senderJid, { text: `❌ Sticker error: ${e.message}` });
                }
                break;
            }

            case 'photo':
            case 'toimg': {
                try {
                    const quotedMsg = m.message.extendedTextMessage?.contextInfo?.quotedMessage;
                    if (!quotedMsg || !quotedMsg.stickerMessage) {
                        return sock.sendMessage(senderJid, { text: '❌ Reply to a sticker with `.photo`' });
                    }
                    const buffer = await downloadMediaBuffer(quotedMsg.stickerMessage, 'sticker');
                    await sock.sendMessage(senderJid, { image: buffer, caption: '🖼️ Converted by Sadiq Bot' });
                } catch (e) {
                    await sock.sendMessage(senderJid, { text: `❌ Conversion failed: ${e.message}` });
                }
                break;
            }

            // ================= TUNELIO ROTATING POOL DOWNLOADERS =================
            case 'play': {
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.play <song name>`' });
                const query = args.join(' ');
                await sock.sendMessage(senderJid, { text: `🔍 Searching audio: *${query}*...` });

                try {
                    const search = await yts(query);
                    const video = search.videos[0];
                    if (!video) return sock.sendMessage(senderJid, { text: '❌ No results found.' });

                    await sock.sendMessage(senderJid, { text: `📥 Downloading real audio file for *${video.title}*...` });

                    let keys = getApiKeys();
                    let streamUrl = null;
                    let successfulKey = null;

                    // Iterate through API key pool until one works
                    for (const key of keys) {
                        try {
                            const tunelioRes = await axios.get(`https://tunelio.dev/create?url=${encodeURIComponent(video.url)}&quality=mp3`, {
                                headers: { 'Authorization': `Bearer ${key}` },
                                timeout: 10000
                            });
                            streamUrl = tunelioRes?.data?.url || tunelioRes?.data?.data?.url;
                            if (streamUrl) {
                                successfulKey = key;
                                break;
                            }
                        } catch (err) {
                            if (err.response && [401, 403, 429].includes(err.response.status)) {
                                console.log(`⚠️ API Key expired/exhausted, auto-removing: ${key.slice(0, 8)}...`);
                                removeApiKey(key);
                            }
                        }
                    }

                    if (!streamUrl) return sock.sendMessage(senderJid, { text: '❌ All API keys in pool are exhausted or failed.' });

                    const audioResponse = await axios.get(streamUrl, { responseType: 'arraybuffer', timeout: 60000 });
                    const audioBuffer = Buffer.from(audioResponse.data);

                    await sock.sendMessage(senderJid, { 
                        audio: audioBuffer, 
                        mimetype: 'audio/mp4',
                        ptt: false,
                        caption: `🎵 *${video.title}*\n⏱ Duration: ${video.timestamp}`
                    });
                } catch (e) {
                    await sock.sendMessage(senderJid, { text: `❌ Download error: ${e.message}` });
                }
                break;
            }

            case 'video': {
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.video <video name>`' });
                const query = args.join(' ');
                await sock.sendMessage(senderJid, { text: `🔍 Searching video: *${query}*...` });

                try {
                    const search = await yts(query);
                    const video = search.videos[0];
                    if (!video) return sock.sendMessage(senderJid, { text: '❌ No results found.' });

                    await sock.sendMessage(senderJid, { text: `📥 Downloading real video file for *${video.title}*...` });

                    let keys = getApiKeys();
                    let streamUrl = null;

                    for (const key of keys) {
                        try {
                            const tunelioRes = await axios.get(`https://tunelio.dev/create?url=${encodeURIComponent(video.url)}&quality=360p`, {
                                headers: { 'Authorization': `Bearer ${key}` },
                                timeout: 10000
                            });
                            streamUrl = tunelioRes?.data?.url || tunelioRes?.data?.data?.url;
                            if (streamUrl) break;
                        } catch (err) {
                            if (err.response && [401, 403, 429].includes(err.response.status)) {
                                console.log(`⚠️ API Key expired/exhausted, auto-removing: ${key.slice(0, 8)}...`);
                                removeApiKey(key);
                            }
                        }
                    }

                    if (!streamUrl) return sock.sendMessage(senderJid, { text: '❌ All API keys in pool are exhausted or failed.' });

                    const videoResponse = await axios.get(streamUrl, { responseType: 'arraybuffer', timeout: 120000 });
                    const videoBuffer = Buffer.from(videoResponse.data);

                    await sock.sendMessage(senderJid, { 
                        video: videoBuffer, 
                        caption: `🎬 *${video.title}*\n⏱ Duration: ${video.timestamp}`
                    });
                } catch (e) {
                    await sock.sendMessage(senderJid, { text: `❌ Download error: ${e.message}` });
                }
                break;
            }

            // ================= MEMES =================
            case 'memes': {
                if (args.length === 0) return sock.sendMessage(senderJid, { text: 'Usage: `.memes <funny text>`' });
                const memeText = args.join(' ');
                const memeUrl = `https://api.memegen.link/images/custom/_/${encodeURIComponent(memeText)}.png?background=https://placehold.co/600x600/1e293b/38bdf8.png?text=SADIQ+MEMES`;
                await sock.sendMessage(senderJid, { image: { url: memeUrl }, caption: '😂 *Generated Meme*' });
                break;
            }

            case 'automemes': {
                const naijaMemes = [
                    "When you borrow money and start avoiding the person like Bluetooth range 🇳🇬",
                    "Nigerian mothers will use towel to clean floor, use it to clean table, then use it to clean face. Legend 💀",
                    "NEPA when everywhere is silent and dark: Let me show them I am still in this country 💡",
                    "When an Okada man takes one corner and your life flashes before your eyes 🚴‍♂️💨",
                    "Telling a Nigerian 'I am coming' is a psychological warfare of 2 to 4 business hours 🕒"
                ];
                const randomMeme = naijaMemes[Math.floor(Math.random() * naijaMemes.length)];
                const memeUrl = `https://api.memegen.link/images/custom/_/${encodeURIComponent(randomMeme)}.png?background=https://placehold.co/600x400/0f172a/38bdf8.png?text=Naija+Vibes`;
                await sock.sendMessage(senderJid, { image: { url: memeUrl }, caption: '🔥 *Automeme*' });
                break;
            }

            // ================= GROUP COMMANDS =================
            case 'antilink':
                if (!isGroup) return sock.sendMessage(senderJid, { text: 'Group-only command.' });
                if (!sessionSettings[senderJid]) sessionSettings[senderJid] = {};
                if (args[0] === 'on') {
                    sessionSettings[senderJid].antiLink = true;
                    await sock.sendMessage(senderJid, { text: '✅ Anti-Link protection enabled.' });
                } else if (args[0] === 'off') {
                    sessionSettings[senderJid].antiLink = false;
                    await sock.sendMessage(senderJid, { text: '❌ Anti-Link protection disabled.' });
                } else {
                    await sock.sendMessage(senderJid, { text: 'Usage: `.antilink on` or `.antilink off`' });
                }
                break;

            // ================= MODE / SYSTEM SWITCHES =================
            case 'public':
                if (!isOwner) return sock.sendMessage(senderJid, { text: '❌ Owner-only command.' });
                globalSettings.publicMode = true;
                await sock.sendMessage(senderJid, { text: '🌐 *Switched to Public Mode.*' });
                break;

            case 'self':
                if (!isOwner) return sock.sendMessage(senderJid, { text: '❌ Owner-only command.' });
                globalSettings.publicMode = false;
                await sock.sendMessage(senderJid, { text: '🔒 *Switched to Self Mode.*' });
                break;

            case 'anticall':
                if (!isOwner) return sock.sendMessage(senderJid, { text: '❌ Owner-only command.' });
                globalSettings.antiCall = args[0] === 'on';
                await sock.sendMessage(senderJid, { text: `Anti-call updated.` });
                break;
        }
    });
}

// Minimal HTTP Health Server for Katabum Cloud Hosting
const PORT = process.env.PORT || 8080;
http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Sadiq Bot Engine Running Successfully');
}).listen(PORT, () => {
    console.log(`🚀 Health Server listening on port ${PORT}`);
});

startWhatsAppSession();
