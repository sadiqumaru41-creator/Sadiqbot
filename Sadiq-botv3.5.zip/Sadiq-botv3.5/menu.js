export const OWNER_NAME = "Sadiq";
export const BUSINESS_NAME = "GFA";
export const BRAND_HEADER = `✨ *𝔁𝔞𝔡𝔦𝔮-𝔪𝔡 𝔪𝔲𝔩𝔱𝔦-𝔟𝔬𝔱* ✨\n👤 *𝔬𝔮𝔫𝔢𝔯:* ${OWNER_NAME}\n🏢 *𝔟𝔲𝔰𝔦𝔫𝔢𝔰𝔰:* ${BUSINESS_NAME}\n`;

export const MAIN_MENU = `${BRAND_HEADER}\n` +
`📜 *𝔠𝔬𝔪𝔪𝔞𝔫𝔡 𝔪𝔢𝔫𝔲*\n\n` +
`🌐 *𝔤𝔢𝔫𝔢𝔯𝔞𝔩*\n` +
`• \`.menu\` - Main menu\n` +
`• \`.ping\` - Bot speed\n` +
`• \`.owner\` - Owner info\n` +
`• \`.profile\` - Get profile pic\n\n` +
`🤖 *𝔞𝔦 𝔰𝔲𝔦𝔱𝔢*\n` +
`• \`.ai <text>\` - NVIDIA AI query\n` +
`• \`.aion\` - Auto AI on\n` +
`• \`.aioff\` - Auto AI off\n\n` +
`🛠️ *𝔲𝔱𝔦𝔩𝔦𝔱𝔦𝔢𝔰*\n` +
`• \`.ss <url>\` - Web screenshot\n` +
`• \`.makeqr <text>\` - Create QR code\n` +
`• \`.tinyurl <link>\` - Shorten link\n` +
`• \`.calc <expr>\` - Calculate\n` +
`• \`.base64 <act> <txt>\` - Encode/decode\n` +
`• \`.fliptext <text>\` - Reverse text\n\n` +
`👥 *𝔤𝔯𝔬𝔲𝔭 𝔞𝔡𝔪𝔦𝔫*\n` +
`• \`.tagall\` - Tag members\n` +
`• \`.hidetag <txt>\` - Hidden tag broadcast\n` +
`• \`.promote\` / \`.demote\` - Admin role\n` +
`• \`.kick\` - Remove member\n` +
`• \`.group open/close\` - Lock chat\n` +
`• \`.setname\` / \`.setdesc\` - Edit group\n` +
`• \`.grouplink\` / \`.revoke\` - Group link\n` +
`• \`.antilink on/off\` - Link shield\n\n` +
`🎵 *𝔪𝔢𝔡𝔦𝔞 & 𝔡𝔬𝔮𝔫𝔩𝔬𝔞𝔡𝔢𝔯*\n` +
`• \`.play <song>\` - Get audio MP3\n` +
`• \`.video <name>\` - Get video MP4\n` +
`• \`.get\` - Grab quoted media\n` +
`• \`.vv\` - Unlock view-once\n` +
`• \`.sticker\` / \`.photo\` - Sticker tool\n\n` +
`🎭 *𝔣𝔲𝔫 & 𝔤𝔞𝔪𝔢𝔰*\n` +
`• \`.truth\` / \`.dare\` - Game prompts\n` +
`• \`.fancy <text>\` - Stylize text\n` +
`• \`.roll\` / \`.flip\` - Dice / Coin\n` +
`• \`.fact\` / \`.joke\` / \`.quote\` - Fun info\n` +
`• \`.memes\` / \`.automemes\` - Custom memes\n\n` +
`🔍 *𝔰𝔢𝔞𝔯𝔠𝔠𝔥 & 𝔦𝔫𝔣𝔬*\n` +
`• \`.weather <city>\` - Weather check\n` +
`• \`.wiki <query>\` - Wikipedia\n` +
`• \`.define <word>\` - Dictionary\n\n` +
`👑 *𝔬𝔮𝔫𝔢𝔯 𝔠𝔬𝔫𝔱𝔯𝔬𝔩𝔰*\n` +
`• \`.public\` / \`.self\` - Switch modes\n` +
`• \`.anticall on/off\` - Block calls\n` +
`• \`.addapikey <key>\` - Add pool key\n` +
`• \`.listkeys\` - List pool keys\n` +
`• \`.delapikey <key/idx>\` - Remove key`;
